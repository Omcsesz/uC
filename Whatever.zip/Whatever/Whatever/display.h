/*
 * display.h
 *
 * Created: 2016. 05. 16. 20:12:24
 *  Author: semuser
 */ 


#ifndef DISPLAY_H_
#define DISPLAY_H_

/************************************************************************/
/*                                                                      */
/************************************************************************/
void lcd_putint(unsigned int input);


#endif /* DISPLAY_H_ */