/*
 * UART.h
 *
 * Created: 2016.05.21. 18:59:37
 *  Author: Omcsesz
 */ 


#ifndef UART_H_
#define UART_H_


char USARTReadChar();
void USARTWriteChar(char data);


#endif /* UART_H_ */